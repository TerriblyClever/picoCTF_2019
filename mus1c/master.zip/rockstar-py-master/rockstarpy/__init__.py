if __name__ == '__main__':
    from .command_line import command_line
    command_line()
