from .command_line import command_line

if __name__ == '__main__':
    command_line()
