def Multiply(Love, Life):
    return Love * Life
print(Multiply(3, 444))
