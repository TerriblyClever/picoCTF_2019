def Multiply(Love, Life):
    return Love * Life
my_heart = 1
the_devil = 666
Multiply(my_heart, the_devil)
